The Visitech and Wintech Calibration Print is a combined calibration pattern used to characterize focus and alignment behavior across two different light engies with different pixel sizes.

The print contains calibration regions for both the Visitech system (15.2 µm pixel size) and the Wintech system (0.75 µm pixel size). Each region includes a focus sweep spanning from −4 to +4 focus steps, allowing the optimal focus position and corresponding calibration corrections to be determined for each system.

Inspect each calibration region under magnification and identify the best focus position based on the sharpest feature resolution. The focus value corresponding to this position is used to determine the required focus correction for the respective projector.