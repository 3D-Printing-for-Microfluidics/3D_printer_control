The Focus Sweep Print is a full-field calibration pattern used to determine the optimal focal distance. The projected pattern contains square features of multiple sizes (1, 2, 4, and 6 pixels) distributed uniformly across the projection field. The pattern consists of 17 columns × 17 rows, with each position containing a 7 × 7 array of features at each pixel size.

Unlike the Uniform Focus Print, each column is printed at a different focus offset. The center column is printed at 0 µm, while adjacent columns step outward by the configured Focus Sweep Step (µm), ranging from −8× the step size on the far left to +8× the step size on the far right. Because focus varies only by column, differences in feature quality directly indicate the relative performance of each focal offset. The column exhibiting the greatest overall feature clarity identifies the optimal global focus.

For orientation, the printed bulk includes a missing notch in the upper-left corner, and the center column omits the first row of features.

The first 2 images below show the projected pixel pattern used for exposure. The remaining images are microscope images of printed features illustrating the appearance of good focus and increasing amounts of defocus.

When evaluating the microscope images, look for the following characteristics:

1. Well-defined feature edges that retain visible pixel structure. At best focus, the edges of the larger (4- and 6-pixel) pillars exhibit a stair-stepped (scalloped) appearance caused by the discrete projected pixels. This is expected and indicates that the optical system is resolving the projected image. As focus degrades, these edge details become smoother and more rounded.
2. Clearly resolved pixel features, including the projected pixel grid and the small dimple corresponding to the center of each DMD micromirror. These fine details are typically visible only when the optical system is very near its optimal focus.
3. Minimal bridging between neighboring features, particularly for the 1- and 2-pixel features, which are the most sensitive to focus and exposure. Individual pillars should remain distinct and well separated.

As defocus increases, the stair-stepped pillar edges, pixel grid, and micromirror dimple become progressively blurred. Neighboring features begin to merge together, especially the smallest pillars, making the optimal focus column easy to identify by comparison.

Note: Feature quality is influenced by both focus and exposure time. If the exposure is too low, pillars may be undersized, incompletely formed, or missing entirely. If the exposure is too high, features become oversized and bridging between neighboring pillars increases, especially for the smallest features. When calibrating the system, it is generally preferable to use an exposure that is slightly on the high side, as slight overexposure is typically easier to compensate for than underexposed or missing features.

##### Single cell pattern

![image exposure pattern](imgs/one_cell.png)

##### Full pattern

![image exposure pattern](slices/full_image.png)

##### Good focus

Features exhibit well-defined, stair-stepped pillar edges, the projected pixel grid and micromirror dimple are clearly visible, and even the smallest features remain well separated.

![image exposure pattern](imgs/0.jpg)

##### 40 µm from good focus

Feature edges begin to smooth and round, fine pixel detail becomes less distinct, and slight bridging may appear between the smallest features.

![image exposure pattern](imgs/40.jpg)

##### 80 µm from good focus

Significant edge blur is visible, the pixel structure is difficult to distinguish, and substantial bridging occurs between neighboring 1- and 2-pixel features, indicating poor focus.

![image exposure pattern](imgs/80.jpg)