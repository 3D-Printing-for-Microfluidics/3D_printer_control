The Uniform Focus Print is a full-field calibration pattern used to evaluate focus consistency across the entire build area. The projected pattern contains square features of multiple sizes (1, 2, 4, and 6 pixels) distributed uniformly across the projection field. The pattern consists of 17 columns × 17 rows, with each position containing a 7 × 7 array of features at each pixel size.

During this test, the entire print is fabricated using a single, fixed focus setting. Because the focus is not adjusted across the field, any variation in feature quality directly indicates changes in focus across the build area. This print is intended as a diagnostic tool to evaluate optical alignment rather than a calibration procedure itself.

The first 2 images below show the projected pixel pattern used for exposure. The remaining images are microscope images of the printed features at different amounts of defocus.

When evaluating the microscope images, look for the following characteristics:

1. Well-defined feature edges that retain visible pixel structure. At best focus, the edges of the larger (4- and 6-pixel) pillars often appear scalloped or stepped rather than perfectly smooth. This is expected and indicates that the projected pixel pattern is being cleanly resolved. As focus degrades, these edge details become rounded and blurred.
2. Clearly resolved pixel features, including the projected pixel grid and the small dimple corresponding to the center of each DMD micromirror. These fine details are typically visible only when the optical system is very near its optimal focus.
3. Minimal bridging between neighboring features, particularly for the 1- and 2-pixel features, which are the most sensitive to focus and exposure. Individual pillars should remain distinct and well separated.

As defocus increases, fine pixel details—including the scalloped pillar edges, pixel grid, and micromirror dimple—become progressively blurred. Feature edges appear smoother and more rounded, and neighboring features, particularly the smallest pillars, begin to merge together.

Note: Feature quality is influenced by both focus and exposure time. If the exposure is too low, pillars may be undersized, incompletely formed, or missing entirely. If the exposure is too high, features become oversized and bridging between neighboring pillars increases, especially for the smallest features. When calibrating the system, it is generally preferable to use an exposure that is slightly on the high side, as small amounts of additional polymerization are typically easier to compensate for than underexposed or missing features.

##### Single cell pattern

![image exposure pattern](imgs/one_cell.png)

##### Full pattern

![image exposure pattern](slices/full_image.png)

##### Good focus

Features exhibit sharp edges, the projected pixel grid and micromirror dimple are clearly visible, and even the smallest features remain well separated.

![image exposure pattern](imgs/0.jpg)

##### 40 µm from good focus

Feature edges begin to soften and corners begin to round, pixel structure is no longer visable, and bridging worsens between the smallest features.

![image exposure pattern](imgs/40.jpg)

##### 80 µm from good focus

Significant rounding of all features, 1-pixel features are no longer resolved and substantial bridging occurs between neighboring 2-pixel features.

![image exposure pattern](imgs/80.jpg)