The Stitching Alignment Print is a multi‑region calibration pattern used to determine stitching corrections from focus and veneer alignment at offset locations. It uses the same 5×5 focus square grids as the Tip/Tilt Focus Sweep print, but the grids are printed at four XY offsets: +X, −X, +Y, and −Y (±5 mm in each axis). Each location includes an X veneer and a Y veneer for alignment checks.

To calibrate, inspect each of the four locations under magnification. For each location, identify the “best square” for focus (sharpest feature resolution) and evaluate veneer alignment for both X and Y veneers. These measurements determine six stitching parameters:

- X adjustment per mm X (divide result by 5)
- Y adjustment per mm X (divide result by 5)
- Focus adjustment per mm X (divide result by 5)
- X adjustment per mm Y (divide result by 5)
- Y adjustment per mm Y (divide result by 5)
- Focus adjustment per mm Y (divide result by 5)

Use the differences between the + and − positions for each axis to compute per‑mm corrections. Apply the resulting values to the stitching adjustments for the corresponding light engine.