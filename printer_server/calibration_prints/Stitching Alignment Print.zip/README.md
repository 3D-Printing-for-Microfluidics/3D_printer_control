The Stitching Alignment Print is a multi-region calibration pattern used to determine stitching corrections for focus and veneer alignment at offset locations.

The pattern uses the same 5 × 5 focus square grids as the Tip/Tilt Focus Sweep print, but the grids are printed at five locations: the center plus four offsets at +X, −X, +Y, and −Y (±5 mm along each axis). Each offset location includes both an X veneer and a Y veneer for alignment evaluation, as shown below.

To calibrate the system, inspect each of the five locations under magnification.

For each location:

1. Identify the best focus square (the square with the sharpest feature resolution). Read the grid starting at the lower-left corner and progressing left to right, then bottom to top. The squares represent focus offsets ranging from −12 × the Focus Sweep Step (µm) at the lower-left corner to +12 × the Focus Sweep Step (µm) at the upper-right corner.
2. Evaluate the alignment of both the X veneer and Y veneer using the veneer alignment marks (highlighted in red in the image below). The alignment mark should be centered on the corresponding veneer; any displacement from the veneer center indicates an alignment offset.
Each tick mark corresponds to approximately 45 µm of displacement and can be used for a quick visual estimate. For best accuracy, measure the veneer offset using a calibrated digital microscope (or other calibrated imaging system) with a known calibration factor. Use the measured displacement rather than the tick-mark estimate whenever possible.

These measurements are used to determine the following stitching correction parameters:

- X adjustment per mm of X offset (divide the measured difference by 5)
- Y adjustment per mm of X offset (divide the measured difference by 5)
- Focus adjustment per mm of X offset (divide the measured difference by 5)
- X adjustment per mm of Y offset (divide the measured difference by 5)
- Y adjustment per mm of Y offset (divide the measured difference by 5)
- Focus adjustment per mm of Y offset (divide the measured difference by 5)

Calculate the per-millimeter corrections by taking the difference between the + and − measurements for each axis and dividing the result by 5 mm. Add the calculated values to the stitching adjustment parameters for the corresponding light engine.

Note: If the center region is not in optimal focus, you may need to adjust the calculated corrections accordingly.

##### Single cell pattern

![image exposure pattern](imgs/one_cell.png)

##### Full pattern

![image exposure pattern](imgs/full_image.png)
