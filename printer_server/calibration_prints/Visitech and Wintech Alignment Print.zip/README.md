The Visitech Wintech Alignment Print is a multi-region calibration pattern used to determine stitching corrections for focus and veneer alignment at offset locations.

The pattern uses a series of X and Y alignment veneers. The veneers are printed at five locations: the center plus four offsets at +X, −X, +Y, and −Y (±5 mm along each axis). 

To calibrate the system, inspect each of the five locations under magnification.

For each location, evaluate the alignment of both the X veneer and Y veneer using the veneer alignment marks. The alignment mark should be centered on the corresponding veneer; any displacement from the veneer center indicates an alignment offset.
Each tick mark corresponds to approximately 45 µm of displacement and can be used for a quick visual estimate. For best accuracy, measure the veneer offset using a calibrated digital microscope (or other calibrated imaging system) with a known calibration factor. Use the measured displacement rather than the tick-mark estimate whenever possible.


These measurements are used to determine the following stitching correction parameters:

Alignment Adjustments (center):

- Wintech - X
- Wintech - Y

Stitching Adjustments:

- Wintech (per mm X) - X (divide the measured difference by 5)
- Wintech (per mm X) - Y (divide the measured difference by 5)
- Wintech (per mm Y) - X (divide the measured difference by 5)
- Wintech (per mm Y) - Y (divide the measured difference by 5)

Calculate the per-millimeter corrections by taking the difference between the + and − measurements for each axis and dividing the result by 5 mm. Add the calculated values to the stitching adjustment parameters for the corresponding light engine.

Additionally, this print also contains a 5 × 5 focus square grids. Identify the best focus square (the square with the sharpest feature resolution). Read the grid starting at the lower-left corner and progressing left to right, then bottom to top. The squares represent focus offsets ranging from −12 × the Focus Sweep Step (µm) at the lower-left corner to +12 × the Focus Sweep Step (µm) at the upper-right corner. This can be used to adjust the wintech focus. Note: on the MR1, each set of 4 squares are replaced with wintech resolution tests.

![image exposure pattern](imgs/full_image.png)


#### Alignment Calculator

<div class="alignment-calculator"></div>

<button type="button" class="btn btn-outline-info" id="add-to-adjustments">Add the results to the current offsets</button>